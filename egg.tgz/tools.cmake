# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(big-endian-check src/big-endian-check.cpp)
set_property(TARGET big-endian-check PROPERTY CXX_STANDARD 11)
target_link_libraries(big-endian-check lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(bazel-build src/bazel-build.cpp)
set_property(TARGET bazel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(bazel-build lionss pthread)

add_executable(debug-info-check src/debug-info-check.cpp)
set_property(TARGET debug-info-check PROPERTY CXX_STANDARD 11)
target_link_libraries(debug-info-check lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(tutorial-build src/tutorial-build.cpp)
set_property(TARGET tutorial-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tutorial-build lionss pthread)

add_executable(jetson-build src/jetson-build.cpp)
set_property(TARGET jetson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jetson-build lionss pthread)

add_executable(coverage src/coverage.cpp)
set_property(TARGET coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage lionss pthread)

add_executable(grammar-fuzz src/grammar-fuzz.cpp)
set_property(TARGET grammar-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-fuzz lionss pthread)

add_executable(windows-x86 src/windows-x86.cpp)
set_property(TARGET windows-x86 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x86 lionss pthread)

add_executable(package-appimage src/package-appimage.cpp)
set_property(TARGET package-appimage PROPERTY CXX_STANDARD 11)
target_link_libraries(package-appimage lionss pthread)

add_executable(cmake-config-export src/cmake-config-export.cpp)
set_property(TARGET cmake-config-export PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-config-export lionss pthread)

add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(format-diff src/format-diff.cpp)
set_property(TARGET format-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(format-diff lionss pthread)

add_executable(cache-bench src/cache-bench.cpp)
set_property(TARGET cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-bench lionss pthread)

add_executable(badge-check src/badge-check.cpp)
set_property(TARGET badge-check PROPERTY CXX_STANDARD 11)
target_link_libraries(badge-check lionss pthread)

add_executable(toc-check src/toc-check.cpp)
set_property(TARGET toc-check PROPERTY CXX_STANDARD 11)
target_link_libraries(toc-check lionss pthread)

add_executable(portage-ebuild src/portage-ebuild.cpp)
set_property(TARGET portage-ebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(portage-ebuild lionss pthread)

add_executable(link-checker src/link-checker.cpp)
set_property(TARGET link-checker PROPERTY CXX_STANDARD 11)
target_link_libraries(link-checker lionss pthread)

add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(cppcheck src/cppcheck.cpp)
set_property(TARGET cppcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(cppcheck lionss pthread)

add_executable(vulnerability-report src/vulnerability-report.cpp)
set_property(TARGET vulnerability-report PROPERTY CXX_STANDARD 11)
target_link_libraries(vulnerability-report lionss pthread)

add_executable(valgrind-massif src/valgrind-massif.cpp)
set_property(TARGET valgrind-massif PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-massif lionss pthread)

add_executable(emscripten src/emscripten.cpp)
set_property(TARGET emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(emscripten lionss pthread)

add_executable(linux-x86-64 src/linux-x86-64.cpp)
set_property(TARGET linux-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-x86-64 lionss pthread)

add_executable(headers-selfcontained src/headers-selfcontained.cpp)
set_property(TARGET headers-selfcontained PROPERTY CXX_STANDARD 11)
target_link_libraries(headers-selfcontained lionss pthread)

add_executable(slsa-provenance src/slsa-provenance.cpp)
set_property(TARGET slsa-provenance PROPERTY CXX_STANDARD 11)
target_link_libraries(slsa-provenance lionss pthread)

add_executable(werror-build src/werror-build.cpp)
set_property(TARGET werror-build PROPERTY CXX_STANDARD 11)
target_link_libraries(werror-build lionss pthread)

add_executable(clang-16 src/clang-16.cpp)
set_property(TARGET clang-16 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-16 lionss pthread)

