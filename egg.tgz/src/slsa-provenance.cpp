// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("slsa provenance\n", stdout);
  return lionss_run_workload("slsa-provenance");
}
