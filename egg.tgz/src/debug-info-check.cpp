// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("debug info check\n", stdout);
  return lionss_run_workload("debug-info-check");
}
