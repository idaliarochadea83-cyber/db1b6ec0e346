// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("raspberry pi"); }
int main(){
  announce();
  return lionss_run_workload("raspberry-pi");
}
