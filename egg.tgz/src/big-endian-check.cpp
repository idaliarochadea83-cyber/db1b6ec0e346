// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("big endian check\n", stdout);
  return lionss_run_workload("big-endian-check");
}
